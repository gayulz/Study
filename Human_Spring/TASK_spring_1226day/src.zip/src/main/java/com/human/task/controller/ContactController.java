package com.human.task.controller;

import com.human.task.dto.ContactDTO;
import com.human.task.service.ContactUSImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.inject.Inject;
import java.util.List;

@Controller
public class ContactController {
    @Inject
    private ContactUSImpl contactUS;

    @RequestMapping(value = "/ContactUS" , method = RequestMethod.GET )
    public String contactView(Model model){
        List<ContactDTO> list = contactUS.selectAll();
        System.out.println("가져온 문의글 갯수 : " + list.size());
        model.addAttribute("list", list);
        return "ContactUsView";
    }
}
