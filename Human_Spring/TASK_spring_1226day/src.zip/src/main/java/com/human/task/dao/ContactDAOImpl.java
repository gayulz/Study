package com.human.task.dao;

import com.human.task.dto.ContactDTO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.util.List;

@Repository
public class ContactDAOImpl implements IF_contactDAO{
    //factory mapping정보
    private static String mapperQuery="com.human.task.dao.IF_contactDAO";
    @Inject
    private SqlSession sqlSession;


    public List<ContactDTO> selectAll(){
        return sqlSession.selectList(mapperQuery+".selectAll");
    }
}
