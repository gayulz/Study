package com.human.task.dao;

import com.human.task.dto.ContactDTO;

import java.util.List;

public interface IF_contactDAO {
    public List<ContactDTO> selectAll();
}
