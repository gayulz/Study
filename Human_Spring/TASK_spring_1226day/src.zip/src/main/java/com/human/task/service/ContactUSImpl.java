package com.human.task.service;

import com.human.task.dao.ContactDAOImpl;
import com.human.task.dto.ContactDTO;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.List;

@Service
public class ContactUSImpl implements IF_contactUS {
    @Inject
    private ContactDAOImpl contactDAO;

    @Override
    public List<ContactDTO> selectAll() {
        return contactDAO.selectAll();
    }
}
