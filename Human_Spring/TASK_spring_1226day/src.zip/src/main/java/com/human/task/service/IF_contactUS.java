package com.human.task.service;

import com.human.task.dto.ContactDTO;

import java.util.List;

public interface IF_contactUS {

    // 게시글을 가져오는 메서드
    public List<ContactDTO> selectAll();

}
